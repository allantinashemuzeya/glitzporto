<div class="fbv-upload-inline">
    <label for="fbv"><?php esc_html_e( 'Choose folder: ', 'filebird' ); ?></label>
    <span id="fbv-folder-selector" class="fbv-folder-selector" name="fbv"></span>
</div>